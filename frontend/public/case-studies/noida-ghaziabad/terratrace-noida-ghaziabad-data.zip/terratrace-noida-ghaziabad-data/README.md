# Noida, Greater Noida and Ghaziabad (Delhi NCR) — data tables

Preliminary results — not peer reviewed. TerraTrace land use / land cover case study, 2015–2025; Abhinav Sinha, Bennett University. Analysis pipeline v1.0.2; tables generated 2026-11-23.

Every result in the PDF report and on the case-study web page comes from these tables; contextual figures from other sources are cited there. `results_summary.md` is the pipeline's own summary of them (written by the pipeline, not by hand).

Units and conventions used in every table:

- Areas are km² on the study's 30 m UTM zone 43N grid (pixel count × 900 m² ÷ 10⁶).
- `season`: `summer` = April–June of the study year (primary; e.g. "April–June 2015"); `winter` = November of the previous year to
  February of the study year (the composite of the withdrawn surface-temperature analysis; not used by the land-cover maps), named by both years it spans (study year 2015 = "winter 2014–15"); `annual` = the whole
  calendar year. Tables keep the study year in `year`; the `composite` column, where present, gives the name.
- Class codes: 1 Built-up and bare land, 2 Vegetation/Trees, 3 Agriculture/Cropland, 4 Water (0 = not classified).
- Shares (`overall_agreement`, `producers_*`, `users_*`, `f1_*`, `*_fraction_*`) are 0–1; `percent_*` columns are 0–100.
- Accuracy columns are AGREEMENT WITH REFERENCE LABELS (held-out GLC-FCS30D-derived points), not accuracy against ground truth.

## Files

### tables/accuracy_metrics.csv

Agreement of the Random Forest map with held-out reference points, per year.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `overall_agreement` | overall agreement with reference labels, 0–1 |
| `kappa` | Cohen's kappa |
| `n_test_points` | held-out test points |
| `n_test_<class>` | test points of that class |
| `producers_<class>` | producer's agreement (reference class correctly mapped), 0–1 |
| `users_<class>` | user's agreement (mapped class matching the reference), 0–1 |
| `f1_<class>` | F1 score, 0–1 |
| `per_class_withheld` | classes with too few test points for per-class figures (empty = none) |

### tables/class_areas.csv

Area of each land-cover class per year.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `class_code` | class code (0 = not classified) |
| `class` | class name |
| `pixels` | number of 30 m pixels |
| `area_km2` | area, km² |
| `percent_of_classified` | share of the classified area, % |

### tables/confusion_matrix_2015.csv

Confusion matrix of the held-out test points, 2015 (counts of points).

| Column | Meaning and unit |
|---|---|
| `reference \ predicted` | reference class (rows); the other columns are the mapped class, values are point counts |

### tables/confusion_matrix_2025.csv

Confusion matrix of the held-out test points, 2025 (counts of points).

| Column | Meaning and unit |
|---|---|
| `reference \ predicted` | reference class (rows); the other columns are the mapped class, values are point counts |

### tables/feature_importance.csv

Random Forest feature importance (Earth Engine `explain()`), per year.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `feature` | input band (Apr–Jun reflectance blue…swir2, indices ndvi/ndbi/mndwi, whole-year NDVI percentiles ndvi_p10/p50/p90) |
| `importance` | importance score (unitless, larger = more used) |

### tables/population.csv

GHSL population and built-up surface summed over the study area, per epoch.

| Column | Meaning and unit |
|---|---|
| `epoch` | GHSL epoch (year) |
| `population` | residents (GHS-POP) |
| `ghsl_built_km2` | GHSL built-up surface, km² (GHS-BUILT-S) |
| `source` | dataset and release |
| `projection_not_estimate` | True = GHSL model projection, not a census-based estimate |

### tables/population_vs_builtup.csv

population.csv joined with this study's built-up area for the study years.

| Column | Meaning and unit |
|---|---|
| `epoch` | GHSL epoch (year) |
| `population` | residents (GHS-POP) |
| `ghsl_built_km2` | GHSL built-up surface, km² |
| `source` | dataset and release |
| `projection_not_estimate` | True = GHSL model projection |
| `builtup_km2_this_study` | built-up area in this study's map, km² (empty for non-study years) |
| `builtup_percent_this_study` | built-up share of the classified area in this study's map, % |

### tables/scene_months.csv

Landsat scenes per calendar month in each seasonal composite (from the scene lists of the Earth Engine run).

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter |
| `composite` | name of the composite |
| `month` | calendar month, YYYY-MM |
| `month_of_season` | 1 = first month of the season |
| `month_name` | month abbreviation |
| `scenes` | scenes acquired in that month |
| `share_of_composite` | share of the composite's scenes, 0–1 |

### tables/scenes.csv

Landsat scenes in each composite.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter / annual |
| `composite` | name of the composite (e.g. winter 2014–15) |
| `sensors` | LC08 = Landsat 8, LC09 = Landsat 9 |
| `scenes` | number of scenes |
| `first_date` | first scene date |
| `last_date` | last scene date |
| `median_date` | median scene date (midpoint of the two middle dates for an even count) |
| `date_ranges` | composite date range(s), end exclusive |

### tables/training_labels.csv

Reference-label pixels available and points drawn per class.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `class` | class name |
| `reference_label_pixels` | stable GLC-FCS30D reference pixels in the study area |
| `train_points` | training points |
| `test_points` | held-out test points |

### tables/transition_2015_2025_km2.csv

Transition matrix: area (km²) that was class *row* in the first year and class *column* in the second.

| Column | Meaning and unit |
|---|---|
| `from \ to` | class in the first year (rows); the other columns are the class in the second year, values in km² |
