# Noida, Greater Noida and Ghaziabad (Delhi NCR) — data tables

Preliminary results — not peer reviewed. TerraTrace LULC + urban heat island case study, 2015–2025; Abhinav Sinha, Bennett University. Analysis pipeline v1.0.0; tables generated 2026-10-20.

Every number in the PDF report and on the case-study web page comes from these tables. `results_summary.md` is the pipeline's own summary of them (written by the pipeline, not by hand).

Units and conventions used in every table:

- Areas are km² on the study's 30 m UTM zone 43N grid (pixel count × 900 m² ÷ 10⁶).
- Temperatures are land surface temperature (LST) in °C from the Landsat thermal band (surface temperature × 0.00341802 + 149 K − 273.15),
  per-pixel median of clear observations at the ~10:30 local overpass.
- `season`: `summer` = April–June of the study year (primary); `winter` = November of the previous year to February (secondary);
  `annual` = the whole calendar year.
- Class codes: 1 Built-up (incl. bare land), 2 Vegetation/Trees, 3 Agriculture/Cropland, 4 Water (0 = not classified).
- Shares (`overall_agreement`, `producers_*`, `users_*`, `f1_*`, `*_fraction_*`) are 0–1; `percent_*` columns are 0–100.
- Accuracy columns are AGREEMENT WITH REFERENCE LABELS (held-out GLC-FCS30D-derived points), not accuracy against ground truth.

## Files

### tables/accuracy_metrics.csv

Agreement of the Random Forest map with held-out reference points, per year.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `overall_agreement` | overall agreement with reference labels, 0–1 |
| `kappa` | Cohen's kappa |
| `n_test_points` | held-out test points |
| `n_test_<class>` | test points of that class |
| `producers_<class>` | producer's agreement (reference class correctly mapped), 0–1 |
| `users_<class>` | user's agreement (mapped class matching the reference), 0–1 |
| `f1_<class>` | F1 score, 0–1 |
| `per_class_withheld` | classes with too few test points for per-class figures (empty = none) |

### tables/class_areas.csv

Area of each land-cover class per year.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `class_code` | class code (0 = not classified) |
| `class` | class name |
| `pixels` | number of 30 m pixels |
| `area_km2` | area, km² |
| `percent_of_classified` | share of the classified area, % |

### tables/confusion_matrix_2015.csv

Confusion matrix of the held-out test points, 2015 (counts of points).

| Column | Meaning and unit |
|---|---|
| `reference \ predicted` | reference class (rows); the other columns are the mapped class, values are point counts |

### tables/confusion_matrix_2025.csv

Confusion matrix of the held-out test points, 2025 (counts of points).

| Column | Meaning and unit |
|---|---|
| `reference \ predicted` | reference class (rows); the other columns are the mapped class, values are point counts |

### tables/conversion_lst_change.csv

LST change of pixels that became built-up vs pixels that kept their class.

| Column | Meaning and unit |
|---|---|
| `period` | first year–second year |
| `season` | summer / winter |
| `group` | transition or stable class |
| `from_code` | class code in the first year |
| `to_code` | class code in the second year |
| `n_pixels` | pixels |
| `area_km2` | area, km² |
| `mean_lst_a_c` | mean LST in the first year, °C |
| `mean_lst_b_c` | mean LST in the second year, °C |
| `mean_delta_lst_c` | mean LST change, °C |
| `mean_delta_z` | mean change of normalised LST, z = (LST − study-area mean) ÷ SD, in standard deviations |

### tables/feature_importance.csv

Random Forest feature importance (Earth Engine `explain()`), per year.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `feature` | input band (Apr–Jun reflectance blue…swir2, indices ndvi/ndbi/mndwi, whole-year NDVI percentiles ndvi_p10/p50/p90) |
| `importance` | importance score (unitless, larger = more used) |

### tables/lst_correlations.csv

Pearson correlation of LST with NDVI and NDBI over land pixels (water excluded).

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter |
| `index` | NDVI or NDBI |
| `r` | Pearson r over all land pixels |
| `n_pixels` | land pixels used |
| `slope_c_per_unit` | least-squares slope, °C per index unit |
| `intercept_c` | intercept, °C |
| `r_thinned` | r on the thinned grid |
| `p_thinned` | two-sided p-value on the thinned grid |
| `n_thinned` | pixels on the thinned grid |
| `thin_spacing_m` | spacing of the thinned grid, m (neighbouring 30 m pixels are not independent) |

### tables/lst_mask_impact.csv

Effect of the LST quality mask (ST_QA > 5 K or ST_EMIS < 0.90 dropped) on each composite.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter |
| `pixels_with_lst_before` | pixels with an LST before the mask |
| `pixels_with_lst_after` | pixels with an LST after the mask |
| `pixels_removed_entirely` | pixels that lost their LST |
| `pixels_changed_over_1c` | pixels whose LST changed by more than 1 °C |
| `pixels_over_55c_before` | pixels above 55 °C before |
| `pixels_over_55c_after` | pixels above 55 °C after |
| `max_land_lst_before_c` | maximum land LST before, °C |
| `max_land_lst_after_c` | maximum land LST after, °C |
| `p99_before_c` | 99th percentile before, °C |
| `p99_after_c` | 99th percentile after, °C |
| `uhi_core_ring_before_c` | UHI core vs ring before, °C |
| `uhi_core_ring_after_c` | UHI core vs ring after, °C |
| `uhi_builtup_before_c` | UHI built-up vs non-built-up before, °C |
| `uhi_builtup_after_c` | UHI built-up vs non-built-up after, °C |

### tables/lst_per_class.csv

Land surface temperature per land-cover class.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter |
| `class_code` | class code |
| `class` | class name |
| `n_pixels` | pixels with a valid LST |
| `mean_c` | mean LST, °C |
| `sd_c` | standard deviation, °C |
| `median_c` | median LST, °C |

### tables/lst_summary.csv

Study-area land surface temperature (water excluded), per year and season.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter |
| `mean_land_c` | mean LST of land pixels, °C |
| `sd_land_c` | standard deviation, °C |
| `p1_c` | 1st percentile, °C |
| `p99_c` | 99th percentile, °C |
| `valid_fraction_of_study_area` | share of the study area with a valid LST, 0–1 |
| `classified_fraction_of_study_area` | share of the study area that is classified, 0–1 |

### tables/population.csv

GHSL population and built-up surface summed over the study area, per epoch.

| Column | Meaning and unit |
|---|---|
| `epoch` | GHSL epoch (year) |
| `population` | residents (GHS-POP) |
| `ghsl_built_km2` | GHSL built-up surface, km² (GHS-BUILT-S) |
| `source` | dataset and release |
| `projection_not_estimate` | True = GHSL model projection, not a census-based estimate |

### tables/population_vs_builtup.csv

population.csv joined with this study's built-up area for the study years.

| Column | Meaning and unit |
|---|---|
| `epoch` | GHSL epoch (year) |
| `population` | residents (GHS-POP) |
| `ghsl_built_km2` | GHSL built-up surface, km² |
| `source` | dataset and release |
| `projection_not_estimate` | True = GHSL model projection |
| `builtup_km2_this_study` | built-up area in this study's map, km² (empty for non-study years) |
| `builtup_percent_this_study` | built-up share of the classified area in this study's map, % |

### tables/scenes.csv

Landsat scenes in each composite.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter / annual |
| `sensors` | LC08 = Landsat 8, LC09 = Landsat 9 |
| `scenes` | number of scenes |
| `first_date` | first scene date |
| `last_date` | last scene date |
| `date_ranges` | composite date range(s), end exclusive |

### tables/training_labels.csv

Reference-label pixels available and points drawn per class.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `class` | class name |
| `reference_label_pixels` | stable GLC-FCS30D reference pixels in the study area |
| `train_points` | training points |
| `test_points` | held-out test points |

### tables/transition_2015_2025_km2.csv

Transition matrix: area (km²) that was class *row* in the first year and class *column* in the second.

| Column | Meaning and unit |
|---|---|
| `from \ to` | class in the first year (rows); the other columns are the class in the second year, values in km² |

### tables/uhi_intensity.csv

Surface urban heat island intensity (urban − rural), two methods.

| Column | Meaning and unit |
|---|---|
| `year` | study year |
| `season` | summer / winter |
| `method` | `urban core vs rural ring` (primary) or `built-up vs non-built-up land` (secondary) |
| `uhi_intensity_c` | urban mean − rural mean, °C (negative = urban cool island) |
| `urban_mean_c` | urban mean LST, °C |
| `rural_mean_c` | rural mean LST, °C |
| `urban_km2` | urban area, km² |
| `rural_km2` | rural area, km² |
| `ring_outer_km` | outer distance of the rural ring from the core, km (core-vs-ring only) |
| `ring_capped` | True if the ring hit its maximum distance before reaching the core's area |
